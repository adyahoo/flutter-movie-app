import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/material.dart';

const placeholder = Color(0xFFCFCFCF);


CustomColors lightCustomColors = const CustomColors(
  sourcePlaceholder: Color(0xFFCFCFCF),
  placeholder: Color(0xFF006874),
  onPlaceholder: Color(0xFFFFFFFF),
  placeholderContainer: Color(0xFF97F0FF),
  onPlaceholderContainer: Color(0xFF001F24),
);

CustomColors darkCustomColors = const CustomColors(
  sourcePlaceholder: Color(0xFFCFCFCF),
  placeholder: Color(0xFF4FD8EB),
  onPlaceholder: Color(0xFF00363D),
  placeholderContainer: Color(0xFF004F58),
  onPlaceholderContainer: Color(0xFF97F0FF),
);



/// Defines a set of custom colors, each comprised of 4 complementary tones.
///
/// See also:
///   * <https://m3.material.io/styles/color/the-color-system/custom-colors>
@immutable
class CustomColors extends ThemeExtension<CustomColors> {
  const CustomColors({
    required this.sourcePlaceholder,
    required this.placeholder,
    required this.onPlaceholder,
    required this.placeholderContainer,
    required this.onPlaceholderContainer,
  });

  final Color? sourcePlaceholder;
  final Color? placeholder;
  final Color? onPlaceholder;
  final Color? placeholderContainer;
  final Color? onPlaceholderContainer;

  @override
  CustomColors copyWith({
    Color? sourcePlaceholder,
    Color? placeholder,
    Color? onPlaceholder,
    Color? placeholderContainer,
    Color? onPlaceholderContainer,
  }) {
    return CustomColors(
      sourcePlaceholder: sourcePlaceholder ?? this.sourcePlaceholder,
      placeholder: placeholder ?? this.placeholder,
      onPlaceholder: onPlaceholder ?? this.onPlaceholder,
      placeholderContainer: placeholderContainer ?? this.placeholderContainer,
      onPlaceholderContainer: onPlaceholderContainer ?? this.onPlaceholderContainer,
    );
  }

  @override
  CustomColors lerp(ThemeExtension<CustomColors>? other, double t) {
    if (other is! CustomColors) {
      return this;
    }
    return CustomColors(
      sourcePlaceholder: Color.lerp(sourcePlaceholder, other.sourcePlaceholder, t),
      placeholder: Color.lerp(placeholder, other.placeholder, t),
      onPlaceholder: Color.lerp(onPlaceholder, other.onPlaceholder, t),
      placeholderContainer: Color.lerp(placeholderContainer, other.placeholderContainer, t),
      onPlaceholderContainer: Color.lerp(onPlaceholderContainer, other.onPlaceholderContainer, t),
    );
  }

  /// Returns an instance of [CustomColors] in which the following custom
  /// colors are harmonized with [dynamic]'s [ColorScheme.primary].
  ///   * [CustomColors.sourcePlaceholder]
  ///   * [CustomColors.placeholder]
  ///   * [CustomColors.onPlaceholder]
  ///   * [CustomColors.placeholderContainer]
  ///   * [CustomColors.onPlaceholderContainer]
  ///
  /// See also:
  ///   * <https://m3.material.io/styles/color/the-color-system/custom-colors#harmonization>
  CustomColors harmonized(ColorScheme dynamic) {
    return copyWith(
      sourcePlaceholder: sourcePlaceholder!.harmonizeWith(dynamic.primary),
      placeholder: placeholder!.harmonizeWith(dynamic.primary),
      onPlaceholder: onPlaceholder!.harmonizeWith(dynamic.primary),
      placeholderContainer: placeholderContainer!.harmonizeWith(dynamic.primary),
      onPlaceholderContainer: onPlaceholderContainer!.harmonizeWith(dynamic.primary),
    );
  }
}